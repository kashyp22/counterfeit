/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 5.6.12-log : Database - counterfiet
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`counterfiet` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `counterfiet`;

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `complaint` varchar(50) DEFAULT NULL,
  `reply` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `complaint` */

insert  into `complaint`(`complaint_id`,`lid`,`date`,`complaint`,`reply`,`status`) values 
(1,7,'2022-11-17','not working','tete','replied'),
(2,8,'2022-11-10','laging','hfjmh','replied'),
(3,9,'2022-11-03','stuck','ok','replied'),
(4,0,'0000-00-00','',NULL,''),
(5,10,'2023-02-09','snd',NULL,'pending'),
(6,10,'2023-02-09','send',NULL,'pending'),
(7,10,'2023-02-09','send',NULL,'pending'),
(8,10,'2023-02-09','complete ',NULL,'pending'),
(9,16,'2023-03-05','vf to xyychctx',NULL,'pending');

/*Table structure for table `feedback` */

DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `feedback` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `feedback` */

insert  into `feedback`(`feedback_id`,`lid`,`feedback`,`date`) values 
(1,7,'GOOD','2022-12-15'),
(2,0,'','0000-00-00'),
(3,0,'','2023-02-09'),
(4,0,'','2023-03-05');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`lid`,`user_name`,`password`,`type`) values 
(1,'admin','123','admin'),
(2,'man','mann','manufacture'),
(3,'kashyapthaz22@gmail.com','123456789+','manufacture'),
(4,'maa','321','manufacture'),
(5,'apple@gmail.com','test','manufacture'),
(6,'vivo@gmail.com','321','manufacture'),
(7,'a@a','aa','manufacture'),
(8,'b@b','bb','manufacture'),
(9,'iphone@gmail.com','345','manufacture'),
(10,'user','use','user'),
(11,'ayana@gmail.com','1234','user'),
(12,'g','i','user'),
(13,'g','i','user'),
(14,'g','i','user'),
(15,'g','i','user'),
(16,'messi@gmail.com','LM10','user');

/*Table structure for table `manufacture` */

DROP TABLE IF EXISTS `manufacture`;

CREATE TABLE `manufacture` (
  `manufacture id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `place` varchar(50) DEFAULT NULL,
  `post` varchar(50) DEFAULT NULL,
  `pin` varchar(10) DEFAULT NULL,
  `district` varchar(40) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `licence` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `logo` varchar(200) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`manufacture id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `manufacture` */

insert  into `manufacture`(`manufacture id`,`lid`,`name`,`place`,`post`,`pin`,`district`,`state`,`licence`,`email`,`phone`,`logo`,`status`) values 
(1,2,'purushettan chayakada','naduvattam','beypore','673015','kozhikode','kerala','369852','purush@gmail.com','9567745645',NULL,'reject '),
(2,3,'book stall','kallai','kallai','673003','kozhikode','kerala','456789','bookstall@gmail.com','3569874123',NULL,'rejected'),
(3,4,'ok new name','kozhikkode','mananchira','673002','kozhikode','kerala','456178','triveni@gmail.com','4667891236','/static/logo/20221226-170052.jpg','reject'),
(4,2,'labourindia','payyanakal','kallai','673003','kozhikode','kerala','457891','labour23@gmail.com','9567762220',NULL,'approved'),
(5,6,'fresh mart','govindapuram','govindapuram','673004','kozhikode','kerala','789456','fresg123@gmail.com','964512378',NULL,'rejected'),
(6,7,'mmart','kallai','kallai','673003','kozhikode','kerala',NULL,NULL,NULL,NULL,'rejected'),
(7,2,'','','','','','','','','','',NULL),
(8,7,'ayush','naduvq','','','','','','','','/static/logo/20221202-122000.jpg','rejected'),
(9,8,'kashyap','kallai','kallai','673003','kozhikode','kerala','999999','kashyapthaz22@gmail.com','123456789+','/static/logo/20221202-122531.jpg','pending'),
(10,5,'apple','payyanakkal','kallai','673003','kozhikode','kerala','987654321','apple@gmail.com','9895621122','/static/logo/20230104-100014.jpg','approved'),
(11,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'rejected'),
(12,6,'vivoo','kallai','kallai','673003','kozhikode','kerala','999999','vivo@gmail.com','9895623147','/static/logo/20230104-115220.jpg','rejected'),
(13,NULL,'ayush','naduvq','','','','','','','','/static/logo/20221202-122000.jpg','pending'),
(14,9,'iphone','ariyadathupalam','mananchira','670006','calicut','kerala','123456456','iphone@gmail.com','1234567891','/static/logo/20230111-102653.jpg','pending');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `place` varchar(50) DEFAULT NULL,
  `post` varchar(10) DEFAULT NULL,
  `pin` varchar(10) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`lid`,`name`,`place`,`post`,`pin`,`district`,`state`,`email`,`phone`,`photo`) values 
(1,7,'ayush','naduvattam','beypore','673015','kozhikode','kerala','ayush@gmail.com','4561237895',NULL),
(2,8,'abinav','payyanakkal','kallai','673003','kozhikode','kerala','abinav 2gmail.com','7894561323',NULL),
(3,9,'adhil','tondayad','tondayad','673004','kozhikode\'','kerala','adhil123@gmai.com','7894891562',NULL),
(4,0,'','','','','','','','',''),
(5,15,'a','b','d','c','e','f','g','h','/static/photo/20230209-181027.jpg'),
(6,16,'messiii','Argentinaaa','Argentinaa','101111','mokloviaaa','sudopiaaa','messi@gmail.com','88778888888','/static/photo/20230305-210002.jpg');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
